// Deze API is verwijderd - geen email verificatie meer
