// Deze pagina is verwijderd - geen email verificatie meer

const EmailVerifiedPage = () => {
  return (
    <div>
      <h1>Email Verified</h1>
      <p>Your email has been successfully verified.</p>
    </div>
  )
}

export default EmailVerifiedPage
