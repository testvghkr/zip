// Deze pagina is verwijderd - geen Gmail setup meer nodig

const GmailSetupPage = () => {
  return (
    <div>
      <h1>Gmail Setup</h1>
      <p>This page is intentionally left blank.</p>
    </div>
  )
}

export default GmailSetupPage
